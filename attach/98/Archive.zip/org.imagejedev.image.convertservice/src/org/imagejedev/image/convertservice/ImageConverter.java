package org.imagejedev.image.convertservice;


import org.imagejdev.image.convert.IImageService;

public class ImageConverter implements IImageService
{
	@Override
	public byte[] convertToGray8( int[] intData ) 
	{
		byte[] out = new byte[intData.length];
		for(int i =0;i<intData.length;i++)
		{
			double rWeight=1d/3d, gWeight=1d/3d,bWeight=1d/3d;
			int c = intData[i];
			int r = (c&0xff0000)>>16;
			int g = (c&0xff00)>>8;
			int b = c&0xff;
			out[i] = (byte)(int)(r*rWeight + g*gWeight + b*bWeight);
		}
		return out;
	}

}
