package org.imagejdev.image.convert;

public interface IImageService {
	
	byte[] convertToGray8( int[] intData );
}