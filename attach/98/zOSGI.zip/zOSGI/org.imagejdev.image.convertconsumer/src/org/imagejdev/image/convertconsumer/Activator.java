package org.imagejdev.image.convertconsumer;


import org.imagejdev.image.convert.IImageService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

public class Activator implements BundleActivator {
	private BundleContext context;
	private IImageService service;

	public void start(BundleContext context) throws Exception {
		this.context = context;
		
		// Register directly with the service
		ServiceReference reference = context.getServiceReference( IImageService.class.getName() );
		service = (IImageService) context.getService(reference);
		
		//Show and tell
		ActionClass.doStuff(service);
	}

	
	public void stop(BundleContext context) throws Exception {
	}

}
