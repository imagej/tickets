package org.imagejdev.image.convertconsumer;

import ij.ImagePlus;
import ij.process.ByteProcessor;
import ij.process.ColorProcessor;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.imagejdev.image.convert.IImageService;

public class ActionClass {
	public static void doStuff(IImageService service) throws IOException
	{
	    String id = "/Users/rick/Documents/w3/org.imagejdev.image.convertconsumer/data/clown.raw";
	    int width = 320;
	    int height = 200;
	    
	    byte[] rawByte = new byte[width*height*3];
	    FileInputStream file = new FileInputStream(id);
		file.read(rawByte);
		
		ColorProcessor cp = new ColorProcessor( width, height, byteArrayToIntArray(rawByte) );

		ImagePlus ip = new ImagePlus();
		ip.setProcessor("test", cp);
		ip.getType();
		
		displayGraphicsInNewJFrame(ip.getBufferedImage(),"Origional ByteProcessor Image", 2000);
		
		byte[] pixels = service.convertToGray8( (int[])cp.getPixels() );
		ByteProcessor bp = new ByteProcessor(width, height, pixels, null);
		
		displayGraphicsInNewJFrame(bp.getBufferedImage(),"Converted Image using OSGI service model", 2000);
    }
	
	public static void displayGraphicsInNewJFrame(BufferedImage i, String label, long millis)
	{
		Dimension preferredSize = new Dimension( i.getWidth(), i.getHeight() );
		JFrame f = new JFrame("ij-test Display");
		f.setPreferredSize(preferredSize);
		
		//f.getContentPane().add("Center", new JScrollPane(new JLabel(new ImageIcon(image))));
		ImageIcon imageIcon = new ImageIcon(i);
		
		JLabel jl = new JLabel();
	
		jl.setIcon(imageIcon);
		//JScrollPane jsp = new JScrollPane(jl); 

		f.getContentPane().add("Center", jl);
		f.getContentPane().add("North", new JLabel(label));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//f.pack();
		f.setSize(preferredSize);
		f.setVisible(true);
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

	/**
	 * Converts a byte[] to an int[]; assumes native byte ordering; 
	 * @param b - Byte[] 
	 * @return
	 */
	private static int[] byteArrayToIntArray(byte[] b ) 
	{
		int intSize = b.length/3;
	
		int[] resultsIntArray = new int[intSize];

		for (int p = 0; p<intSize; p++)
		{
			int len = 3;
			byte[] bytes = new byte[3];
			System.arraycopy(b, p*3, bytes, 0, bytes.length);
			int off = 0;

			if (bytes.length - off < len) len = bytes.length - off;
			int total = 0; int ndx=off; int i = 0;

			int red = (bytes[ndx] < 0 ? 256 + bytes[ndx] : (int) bytes[ndx]) << ((len - i - 1) * 8);
			ndx++;i++;
			
			int green = (bytes[ndx] < 0 ? 256 + bytes[ndx] : (int) bytes[ndx]) << (( len - i - 1) * 8);
			ndx++;i++;
			
			int blue = (bytes[ndx] < 0 ? 256 + bytes[ndx] : (int) bytes[ndx]) << (( len - i - 1) * 8);
			
			int alpha = (byte)0x00;

			total = red | green | blue | alpha; 

			resultsIntArray[p] = total;
		}

		return resultsIntArray;
	}
	
}
